import { useState } from 'react';
import { motion } from 'motion/react';
import { Search, Star, MapPin, LogOut, User, Moon, Sun, Sparkles } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { teachers } from './mockData';
import { useTheme } from './ThemeContext';

interface HomepageProps {
  user: any;
}

export default function Homepage({ user }: HomepageProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSkill, setSelectedSkill] = useState<string | null>(null);
  const navigate = useNavigate();
  const { theme, toggleTheme } = useTheme();

  const handleLogout = () => {
    localStorage.removeItem('collabUser');
    localStorage.removeItem('collabProfile');
    window.location.href = '/';
  };

  const allSkills = Array.from(new Set(teachers.flatMap(t => t.skills)));

  const filteredTeachers = teachers.filter(teacher => {
    const matchesSearch = teacher.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      teacher.skills.some(s => s.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesSkill = !selectedSkill || teacher.skills.includes(selectedSkill);
    return matchesSearch && matchesSkill;
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-teal-50 dark:from-gray-900 dark:via-purple-900/20 dark:to-teal-900/20">
      {/* Header */}
      <div className="sticky top-0 z-50 backdrop-blur-xl bg-white/70 dark:bg-gray-900/70 border-b border-gray-200/50 dark:border-gray-700/50">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-3 rounded-2xl bg-gradient-to-br from-purple-500 to-teal-500 shadow-lg">
                <Sparkles className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl bg-gradient-to-r from-purple-600 to-teal-600 dark:from-purple-400 dark:to-teal-400 bg-clip-text text-transparent">
                  Collab
                </h1>
                <p className="text-xs text-gray-600 dark:text-gray-400">Welcome, {user.name}</p>
              </div>
            </div>
            
            <div className="flex items-center gap-3">
              <button
                onClick={toggleTheme}
                className="p-3 rounded-xl bg-gray-100 dark:bg-gray-800 hover:scale-105 transition-transform"
              >
                {theme === 'light' ? (
                  <Moon className="w-5 h-5 text-gray-700 dark:text-gray-200" />
                ) : (
                  <Sun className="w-5 h-5 text-gray-200" />
                )}
              </button>
              <button className="p-3 rounded-xl bg-gray-100 dark:bg-gray-800 hover:scale-105 transition-transform">
                <User className="w-5 h-5 text-gray-700 dark:text-gray-200" />
              </button>
              <button
                onClick={handleLogout}
                className="p-3 rounded-xl bg-red-100 dark:bg-red-900/30 hover:scale-105 transition-transform"
              >
                <LogOut className="w-5 h-5 text-red-600 dark:text-red-400" />
              </button>
            </div>
          </div>

          {/* Search Bar */}
          <div className="mt-6">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                placeholder="Search for skills or teachers..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-12 pr-4 py-4 rounded-2xl bg-white/50 dark:bg-gray-800/50 border border-gray-200/50 dark:border-gray-700/50 focus:border-purple-500 dark:focus:border-purple-400 focus:ring-2 focus:ring-purple-500/20 outline-none transition-all text-gray-800 dark:text-gray-100 placeholder-gray-500 dark:placeholder-gray-400"
              />
            </div>
          </div>

          {/* Skill Filters */}
          <div className="mt-4 flex gap-2 overflow-x-auto pb-2 hide-scrollbar">
            <button
              onClick={() => setSelectedSkill(null)}
              className={`px-4 py-2 rounded-xl whitespace-nowrap transition-all ${
                !selectedSkill
                  ? 'bg-gradient-to-r from-purple-600 to-teal-600 text-white shadow-lg'
                  : 'bg-white/50 dark:bg-gray-800/50 text-gray-700 dark:text-gray-300 hover:bg-white dark:hover:bg-gray-800'
              }`}
            >
              All Skills
            </button>
            {allSkills.map(skill => (
              <button
                key={skill}
                onClick={() => setSelectedSkill(skill)}
                className={`px-4 py-2 rounded-xl whitespace-nowrap transition-all ${
                  selectedSkill === skill
                    ? 'bg-gradient-to-r from-purple-600 to-teal-600 text-white shadow-lg'
                    : 'bg-white/50 dark:bg-gray-800/50 text-gray-700 dark:text-gray-300 hover:bg-white dark:hover:bg-gray-800'
                }`}
              >
                {skill}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Teacher Cards Grid */}
      <div className="max-w-7xl mx-auto px-4 py-8">
        <h2 className="text-2xl mb-6 text-gray-800 dark:text-gray-100">
          {selectedSkill ? `Best ${selectedSkill} Teachers` : 'Top Teachers'}
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredTeachers.map((teacher, index) => (
            <motion.div
              key={teacher.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Link to={`/teacher/${teacher.id}`}>
                <motion.div
                  whileHover={{ y: -8, scale: 1.02 }}
                  className="h-full rounded-3xl bg-white/40 dark:bg-gray-800/40 backdrop-blur-xl border border-white/20 dark:border-gray-700/20 shadow-xl hover:shadow-2xl transition-all overflow-hidden cursor-pointer"
                >
                  {/* Profile Image */}
                  <div className="relative h-48 overflow-hidden">
                    <img
                      src={teacher.profilePhoto}
                      alt={teacher.name}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                    <div className="absolute bottom-4 left-4 right-4">
                      <h3 className="text-xl text-white mb-1">{teacher.name}</h3>
                      <p className="text-sm text-gray-200">{teacher.profession}</p>
                    </div>
                  </div>

                  {/* Card Content */}
                  <div className="p-6">
                    <div className="flex items-center gap-2 mb-3">
                      <MapPin className="w-4 h-4 text-gray-500 dark:text-gray-400" />
                      <span className="text-sm text-gray-600 dark:text-gray-300">{teacher.location}</span>
                    </div>

                    <div className="flex flex-wrap gap-2 mb-4">
                      {teacher.skills.slice(0, 3).map(skill => (
                        <span
                          key={skill}
                          className="px-3 py-1 rounded-full bg-purple-100 dark:bg-purple-900/30 text-purple-700 dark:text-purple-300 text-xs"
                        >
                          {skill}
                        </span>
                      ))}
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="flex items-center gap-1">
                          <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                          <span className="text-gray-800 dark:text-gray-100">{teacher.rating}</span>
                        </div>
                        <span className="text-sm text-gray-500 dark:text-gray-400">
                          ({teacher.reviews} reviews)
                        </span>
                      </div>
                      <span className="text-sm text-gray-600 dark:text-gray-300">{teacher.experience}</span>
                    </div>

                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className="w-full mt-4 py-3 rounded-xl bg-gradient-to-r from-purple-600 to-teal-600 hover:from-purple-700 hover:to-teal-700 text-white transition-all"
                    >
                      Learn More
                    </motion.button>
                  </div>
                </motion.div>
              </Link>
            </motion.div>
          ))}
        </div>

        {filteredTeachers.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-500 dark:text-gray-400">No teachers found matching your criteria.</p>
          </div>
        )}
      </div>

      <style>{`
        .hide-scrollbar::-webkit-scrollbar {
          display: none;
        }
        .hide-scrollbar {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
      `}</style>
    </div>
  );
}
