import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { useParams, Link } from 'react-router-dom';
import { Star, Award, Trophy, Medal, Sparkles, Moon, Sun } from 'lucide-react';
import { teachers } from './mockData';
import { useTheme } from './ThemeContext';

export default function CompletionFeedback() {
  const { teacherId } = useParams();
  const teacher = teachers.find(t => t.id === teacherId);
  const [rating, setRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);
  const [feedback, setFeedback] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [showConfetti, setShowConfetti] = useState(false);
  const { theme, toggleTheme } = useTheme();

  useEffect(() => {
    setShowConfetti(true);
  }, []);

  if (!teacher) {
    return <div>Teacher not found</div>;
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setShowConfetti(true);
  };

  const badges = [
    { name: 'Bronze', icon: Medal, color: 'from-orange-400 to-orange-600', unlocked: true },
    { name: 'Silver', icon: Award, color: 'from-gray-300 to-gray-500', unlocked: true },
    { name: 'Gold', icon: Trophy, color: 'from-yellow-400 to-yellow-600', unlocked: rating >= 4 },
    { name: 'Platinum', icon: Sparkles, color: 'from-purple-400 to-purple-600', unlocked: rating === 5 }
  ];

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-blue-50 via-purple-50 to-teal-50 dark:from-gray-900 dark:via-purple-900/20 dark:to-teal-900/20" />
      
      {/* Animated Blobs */}
      <div className="absolute top-0 -left-20 w-96 h-96 bg-purple-300 dark:bg-purple-500/30 rounded-full mix-blend-multiply dark:mix-blend-soft-light filter blur-3xl opacity-70 animate-blob" />
      <div className="absolute top-0 -right-20 w-96 h-96 bg-teal-300 dark:bg-teal-500/30 rounded-full mix-blend-multiply dark:mix-blend-soft-light filter blur-3xl opacity-70 animate-blob animation-delay-2000" />
      <div className="absolute -bottom-20 left-20 w-96 h-96 bg-blue-300 dark:bg-blue-500/30 rounded-full mix-blend-multiply dark:mix-blend-soft-light filter blur-3xl opacity-70 animate-blob animation-delay-4000" />

      {/* Confetti */}
      {showConfetti && (
        <div className="absolute inset-0 pointer-events-none">
          {[...Array(50)].map((_, i) => (
            <motion.div
              key={i}
              initial={{ y: -20, x: Math.random() * window.innerWidth, opacity: 1 }}
              animate={{ 
                y: window.innerHeight + 20, 
                x: Math.random() * window.innerWidth,
                rotate: Math.random() * 360,
                opacity: 0
              }}
              transition={{ 
                duration: Math.random() * 2 + 2, 
                delay: Math.random() * 0.5,
                ease: 'easeOut'
              }}
              className={`absolute w-2 h-2 rounded-full ${
                ['bg-purple-500', 'bg-teal-500', 'bg-yellow-500', 'bg-pink-500', 'bg-blue-500'][i % 5]
              }`}
            />
          ))}
        </div>
      )}

      {/* Theme Toggle */}
      <button
        onClick={toggleTheme}
        className="absolute top-6 right-6 z-10 p-3 rounded-2xl bg-white/30 dark:bg-gray-800/30 backdrop-blur-lg border border-white/20 dark:border-gray-700/20 shadow-lg hover:scale-110 transition-transform"
      >
        {theme === 'light' ? (
          <Moon className="w-5 h-5 text-gray-700 dark:text-gray-200" />
        ) : (
          <Sun className="w-5 h-5 text-gray-200" />
        )}
      </button>

      {/* Content */}
      <div className="relative z-10 min-h-screen flex items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="w-full max-w-2xl"
        >
          {!submitted ? (
            <div className="rounded-3xl bg-white/40 dark:bg-gray-800/40 backdrop-blur-2xl border border-white/20 dark:border-gray-700/20 shadow-2xl p-8">
              {/* Header */}
              <div className="text-center mb-8">
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: 0.2, type: 'spring', stiffness: 200 }}
                  className="inline-block p-4 rounded-full bg-gradient-to-br from-purple-500 to-teal-500 mb-4"
                >
                  <Trophy className="w-12 h-12 text-white" />
                </motion.div>
                <h1 className="text-3xl mb-2 text-gray-800 dark:text-gray-100">
                  Course Completed! 🎉
                </h1>
                <p className="text-gray-600 dark:text-gray-300">
                  You've finished learning with {teacher.name}
                </p>
              </div>

              {/* Progress Summary */}
              <div className="rounded-2xl bg-gradient-to-r from-purple-100 to-teal-100 dark:from-purple-900/30 dark:to-teal-900/30 p-6 mb-8">
                <div className="flex items-center gap-4">
                  <img
                    src={teacher.profilePhoto}
                    alt={teacher.name}
                    className="w-16 h-16 rounded-full object-cover border-2 border-white dark:border-gray-700"
                  />
                  <div className="flex-1">
                    <h3 className="text-lg text-gray-800 dark:text-gray-100">{teacher.name}</h3>
                    <p className="text-gray-600 dark:text-gray-300">
                      {teacher.skills.join(', ')}
                    </p>
                  </div>
                </div>
              </div>

              {/* Feedback Form */}
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label className="block mb-3 text-gray-700 dark:text-gray-200 text-center">
                    Rate Your Experience
                  </label>
                  <div className="flex justify-center gap-2">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <motion.button
                        key={star}
                        type="button"
                        onClick={() => setRating(star)}
                        onMouseEnter={() => setHoverRating(star)}
                        onMouseLeave={() => setHoverRating(0)}
                        whileHover={{ scale: 1.2 }}
                        whileTap={{ scale: 0.9 }}
                        className="focus:outline-none"
                      >
                        <Star
                          className={`w-10 h-10 transition-all ${
                            star <= (hoverRating || rating)
                              ? 'fill-yellow-400 text-yellow-400'
                              : 'text-gray-300 dark:text-gray-600'
                          }`}
                        />
                      </motion.button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block mb-2 text-gray-700 dark:text-gray-200">
                    Share Your Feedback
                  </label>
                  <textarea
                    value={feedback}
                    onChange={(e) => setFeedback(e.target.value)}
                    required
                    rows={4}
                    placeholder="What did you learn? How was your experience?"
                    className="w-full px-5 py-4 rounded-2xl bg-white/50 dark:bg-gray-700/50 border border-gray-200/50 dark:border-gray-600/50 focus:border-purple-500 dark:focus:border-purple-400 focus:ring-2 focus:ring-purple-500/20 outline-none transition-all text-gray-800 dark:text-gray-100 placeholder-gray-500 dark:placeholder-gray-400 resize-none"
                  />
                </div>

                <motion.button
                  type="submit"
                  disabled={rating === 0}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="w-full py-4 rounded-2xl bg-gradient-to-r from-purple-600 to-teal-600 hover:from-purple-700 hover:to-teal-700 text-white shadow-lg hover:shadow-xl transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Submit Feedback
                </motion.button>
              </form>
            </div>
          ) : (
            <div className="rounded-3xl bg-white/40 dark:bg-gray-800/40 backdrop-blur-2xl border border-white/20 dark:border-gray-700/20 shadow-2xl p-8 text-center">
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: 'spring', stiffness: 200 }}
                className="inline-block p-4 rounded-full bg-gradient-to-br from-green-500 to-teal-500 mb-4"
              >
                <Sparkles className="w-12 h-12 text-white" />
              </motion.div>
              
              <h1 className="text-3xl mb-4 text-gray-800 dark:text-gray-100">
                Thank You! 🌟
              </h1>
              <p className="text-gray-600 dark:text-gray-300 mb-8">
                Your feedback helps us improve the learning experience
              </p>

              {/* Reward Points */}
              <div className="rounded-2xl bg-gradient-to-r from-yellow-100 to-orange-100 dark:from-yellow-900/30 dark:to-orange-900/30 p-6 mb-8">
                <p className="text-gray-600 dark:text-gray-300 mb-2">Reward Points Earned</p>
                <motion.p
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: 0.2, type: 'spring', stiffness: 200 }}
                  className="text-5xl bg-gradient-to-r from-yellow-600 to-orange-600 dark:from-yellow-400 dark:to-orange-400 bg-clip-text text-transparent"
                >
                  +{rating * 20}
                </motion.p>
              </div>

              {/* Badges */}
              <div className="mb-8">
                <p className="text-gray-700 dark:text-gray-200 mb-4">Your Achievement Badges</p>
                <div className="flex justify-center gap-4">
                  {badges.map((badge, index) => {
                    const Icon = badge.icon;
                    return (
                      <motion.div
                        key={badge.name}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.1 }}
                        className="relative"
                      >
                        <div
                          className={`p-4 rounded-2xl ${
                            badge.unlocked
                              ? `bg-gradient-to-br ${badge.color} shadow-lg`
                              : 'bg-gray-200 dark:bg-gray-700'
                          } transition-all`}
                        >
                          <Icon className={`w-8 h-8 ${badge.unlocked ? 'text-white' : 'text-gray-400 dark:text-gray-600'}`} />
                        </div>
                        <p className={`text-xs mt-2 ${badge.unlocked ? 'text-gray-800 dark:text-gray-100' : 'text-gray-400 dark:text-gray-600'}`}>
                          {badge.name}
                        </p>
                        {badge.unlocked && (
                          <motion.div
                            initial={{ scale: 0 }}
                            animate={{ scale: 1 }}
                            className="absolute -top-1 -right-1 w-6 h-6 bg-green-500 rounded-full flex items-center justify-center"
                          >
                            <Sparkles className="w-4 h-4 text-white" />
                          </motion.div>
                        )}
                      </motion.div>
                    );
                  })}
                </div>
              </div>

              <Link to="/home">
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="w-full py-4 rounded-2xl bg-gradient-to-r from-purple-600 to-teal-600 hover:from-purple-700 hover:to-teal-700 text-white shadow-lg hover:shadow-xl transition-all"
                >
                  Back to Home
                </motion.button>
              </Link>
            </div>
          )}
        </motion.div>
      </div>

      <style>{`
        @keyframes blob {
          0% { transform: translate(0px, 0px) scale(1); }
          33% { transform: translate(30px, -50px) scale(1.1); }
          66% { transform: translate(-20px, 20px) scale(0.9); }
          100% { transform: translate(0px, 0px) scale(1); }
        }
        .animate-blob {
          animation: blob 7s infinite;
        }
        .animation-delay-2000 {
          animation-delay: 2s;
        }
        .animation-delay-4000 {
          animation-delay: 4s;
        }
      `}</style>
    </div>
  );
}
