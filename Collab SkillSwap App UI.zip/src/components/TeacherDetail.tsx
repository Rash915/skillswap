import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { ArrowLeft, Star, MapPin, Award, GraduationCap, Briefcase, MessageCircle, ChevronDown, Video, FileText, Clock, Moon, Sun } from 'lucide-react';
import { teachers, teacherReviews } from './mockData';
import { useTheme } from './ThemeContext';

export default function TeacherDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const teacher = teachers.find(t => t.id === id);
  const reviews = teacherReviews[id || ''] || [];
  const [expandedSection, setExpandedSection] = useState<string | null>('about');
  const { theme, toggleTheme } = useTheme();

  if (!teacher) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>Teacher not found</p>
      </div>
    );
  }

  const toggleSection = (section: string) => {
    setExpandedSection(expandedSection === section ? null : section);
  };

  const handleSendRequest = () => {
    navigate(`/chat/${teacher.id}`);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-teal-50 dark:from-gray-900 dark:via-purple-900/20 dark:to-teal-900/20">
      {/* Hero Banner */}
      <div className="relative h-72 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-purple-600 to-teal-600" />
        <img
          src={teacher.profilePhoto}
          alt={teacher.name}
          className="absolute inset-0 w-full h-full object-cover opacity-20"
        />
        
        {/* Back Button */}
        <Link
          to="/home"
          className="absolute top-6 left-6 p-3 rounded-2xl bg-white/30 dark:bg-gray-800/30 backdrop-blur-lg border border-white/20 dark:border-gray-700/20 shadow-lg hover:scale-110 transition-transform"
        >
          <ArrowLeft className="w-5 h-5 text-white" />
        </Link>

        {/* Theme Toggle */}
        <button
          onClick={toggleTheme}
          className="absolute top-6 right-6 p-3 rounded-2xl bg-white/30 dark:bg-gray-800/30 backdrop-blur-lg border border-white/20 dark:border-gray-700/20 shadow-lg hover:scale-110 transition-transform"
        >
          {theme === 'light' ? (
            <Moon className="w-5 h-5 text-white" />
          ) : (
            <Sun className="w-5 h-5 text-white" />
          )}
        </button>

        {/* Profile Photo */}
        <div className="absolute -bottom-16 left-1/2 -translate-x-1/2">
          <div className="relative">
            <img
              src={teacher.profilePhoto}
              alt={teacher.name}
              className="w-32 h-32 rounded-full border-4 border-white dark:border-gray-800 shadow-2xl object-cover"
            />
            <div className="absolute -bottom-2 -right-2 p-2 rounded-full bg-green-500 border-2 border-white dark:border-gray-800">
              <div className="w-3 h-3 rounded-full bg-white" />
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-4xl mx-auto px-4 pt-20 pb-12">
        {/* Header Info */}
        <div className="text-center mb-8">
          <h1 className="text-4xl mb-2 text-gray-800 dark:text-gray-100">{teacher.name}</h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 mb-4">{teacher.profession}</p>
          
          <div className="flex items-center justify-center gap-6 mb-4">
            <div className="flex items-center gap-2">
              <Star className="w-5 h-5 fill-yellow-400 text-yellow-400" />
              <span className="text-gray-800 dark:text-gray-100">{teacher.rating}</span>
              <span className="text-gray-500 dark:text-gray-400">({teacher.reviews} reviews)</span>
            </div>
            <div className="flex items-center gap-2">
              <MapPin className="w-5 h-5 text-gray-500 dark:text-gray-400" />
              <span className="text-gray-600 dark:text-gray-300">{teacher.location}</span>
            </div>
          </div>

          <div className="flex flex-wrap justify-center gap-2">
            {teacher.skills.map(skill => (
              <span
                key={skill}
                className="px-4 py-2 rounded-full bg-purple-100 dark:bg-purple-900/30 text-purple-700 dark:text-purple-300"
              >
                {skill}
              </span>
            ))}
          </div>
        </div>

        {/* Accordion Sections */}
        <div className="space-y-4 mb-8">
          {/* About Section */}
          <motion.div
            className="rounded-3xl bg-white/40 dark:bg-gray-800/40 backdrop-blur-xl border border-white/20 dark:border-gray-700/20 shadow-lg overflow-hidden"
          >
            <button
              onClick={() => toggleSection('about')}
              className="w-full px-6 py-4 flex items-center justify-between hover:bg-white/20 dark:hover:bg-gray-700/20 transition-all"
            >
              <div className="flex items-center gap-3">
                <Briefcase className="w-5 h-5 text-purple-600 dark:text-purple-400" />
                <span className="text-lg text-gray-800 dark:text-gray-100">About</span>
              </div>
              <motion.div
                animate={{ rotate: expandedSection === 'about' ? 180 : 0 }}
                transition={{ duration: 0.3 }}
              >
                <ChevronDown className="w-5 h-5 text-gray-600 dark:text-gray-300" />
              </motion.div>
            </button>
            <AnimatePresence>
              {expandedSection === 'about' && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.3 }}
                  className="overflow-hidden"
                >
                  <div className="px-6 pb-6">
                    <p className="text-gray-700 dark:text-gray-300">{teacher.bio}</p>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>

          {/* Experience Section */}
          <motion.div
            className="rounded-3xl bg-white/40 dark:bg-gray-800/40 backdrop-blur-xl border border-white/20 dark:border-gray-700/20 shadow-lg overflow-hidden"
          >
            <button
              onClick={() => toggleSection('experience')}
              className="w-full px-6 py-4 flex items-center justify-between hover:bg-white/20 dark:hover:bg-gray-700/20 transition-all"
            >
              <div className="flex items-center gap-3">
                <Award className="w-5 h-5 text-purple-600 dark:text-purple-400" />
                <span className="text-lg text-gray-800 dark:text-gray-100">Experience & Education</span>
              </div>
              <motion.div
                animate={{ rotate: expandedSection === 'experience' ? 180 : 0 }}
                transition={{ duration: 0.3 }}
              >
                <ChevronDown className="w-5 h-5 text-gray-600 dark:text-gray-300" />
              </motion.div>
            </button>
            <AnimatePresence>
              {expandedSection === 'experience' && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.3 }}
                  className="overflow-hidden"
                >
                  <div className="px-6 pb-6 space-y-4">
                    <div className="flex items-start gap-3">
                      <Briefcase className="w-5 h-5 text-gray-500 dark:text-gray-400 mt-1" />
                      <div>
                        <p className="text-gray-600 dark:text-gray-400 text-sm">Experience</p>
                        <p className="text-gray-800 dark:text-gray-100">{teacher.experience}</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <GraduationCap className="w-5 h-5 text-gray-500 dark:text-gray-400 mt-1" />
                      <div>
                        <p className="text-gray-600 dark:text-gray-400 text-sm">Education</p>
                        <p className="text-gray-800 dark:text-gray-100">{teacher.education}</p>
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>

          {/* Teaching Method Section */}
          <motion.div
            className="rounded-3xl bg-white/40 dark:bg-gray-800/40 backdrop-blur-xl border border-white/20 dark:border-gray-700/20 shadow-lg overflow-hidden"
          >
            <button
              onClick={() => toggleSection('teaching')}
              className="w-full px-6 py-4 flex items-center justify-between hover:bg-white/20 dark:hover:bg-gray-700/20 transition-all"
            >
              <div className="flex items-center gap-3">
                <Video className="w-5 h-5 text-purple-600 dark:text-purple-400" />
                <span className="text-lg text-gray-800 dark:text-gray-100">Teaching Methods</span>
              </div>
              <motion.div
                animate={{ rotate: expandedSection === 'teaching' ? 180 : 0 }}
                transition={{ duration: 0.3 }}
              >
                <ChevronDown className="w-5 h-5 text-gray-600 dark:text-gray-300" />
              </motion.div>
            </button>
            <AnimatePresence>
              {expandedSection === 'teaching' && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.3 }}
                  className="overflow-hidden"
                >
                  <div className="px-6 pb-6">
                    <div className="grid grid-cols-2 gap-3">
                      {teacher.teachingMethod.map(method => (
                        <div
                          key={method}
                          className="flex items-center gap-2 px-4 py-3 rounded-xl bg-teal-100 dark:bg-teal-900/30 text-teal-700 dark:text-teal-300"
                        >
                          {method.includes('Video') ? <Video className="w-4 h-4" /> :
                           method.includes('PDF') ? <FileText className="w-4 h-4" /> :
                           <Clock className="w-4 h-4" />}
                          <span className="text-sm">{method}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>

          {/* Reviews Section */}
          <motion.div
            className="rounded-3xl bg-white/40 dark:bg-gray-800/40 backdrop-blur-xl border border-white/20 dark:border-gray-700/20 shadow-lg overflow-hidden"
          >
            <button
              onClick={() => toggleSection('reviews')}
              className="w-full px-6 py-4 flex items-center justify-between hover:bg-white/20 dark:hover:bg-gray-700/20 transition-all"
            >
              <div className="flex items-center gap-3">
                <Star className="w-5 h-5 text-purple-600 dark:text-purple-400" />
                <span className="text-lg text-gray-800 dark:text-gray-100">Reviews ({reviews.length})</span>
              </div>
              <motion.div
                animate={{ rotate: expandedSection === 'reviews' ? 180 : 0 }}
                transition={{ duration: 0.3 }}
              >
                <ChevronDown className="w-5 h-5 text-gray-600 dark:text-gray-300" />
              </motion.div>
            </button>
            <AnimatePresence>
              {expandedSection === 'reviews' && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.3 }}
                  className="overflow-hidden"
                >
                  <div className="px-6 pb-6 space-y-4">
                    {reviews.length > 0 ? (
                      reviews.map(review => (
                        <div
                          key={review.id}
                          className="p-4 rounded-xl bg-white/30 dark:bg-gray-700/30"
                        >
                          <div className="flex items-center gap-3 mb-2">
                            <img
                              src={review.userPhoto}
                              alt={review.userName}
                              className="w-10 h-10 rounded-full object-cover"
                            />
                            <div className="flex-1">
                              <p className="text-gray-800 dark:text-gray-100">{review.userName}</p>
                              <div className="flex items-center gap-1">
                                {[...Array(5)].map((_, i) => (
                                  <Star
                                    key={i}
                                    className={`w-4 h-4 ${
                                      i < review.rating
                                        ? 'fill-yellow-400 text-yellow-400'
                                        : 'text-gray-300 dark:text-gray-600'
                                    }`}
                                  />
                                ))}
                              </div>
                            </div>
                            <span className="text-sm text-gray-500 dark:text-gray-400">
                              {new Date(review.date).toLocaleDateString()}
                            </span>
                          </div>
                          <p className="text-gray-700 dark:text-gray-300">{review.comment}</p>
                        </div>
                      ))
                    ) : (
                      <p className="text-gray-500 dark:text-gray-400 text-center py-4">No reviews yet</p>
                    )}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        </div>

        {/* Send Request Button */}
        <motion.button
          onClick={handleSendRequest}
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          className="w-full py-5 rounded-2xl bg-gradient-to-r from-purple-600 to-teal-600 hover:from-purple-700 hover:to-teal-700 text-white shadow-2xl hover:shadow-3xl transition-all flex items-center justify-center gap-3"
        >
          <MessageCircle className="w-6 h-6" />
          <span className="text-lg">Send Chat Request</span>
        </motion.button>
      </div>
    </div>
  );
}
