import { useState, useRef, useEffect } from 'react';
import { motion } from 'motion/react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { ArrowLeft, Send, Paperclip, FileText, Video, CheckCircle2, Moon, Sun } from 'lucide-react';
import { teachers, mockChatHistory, ChatMessage } from './mockData';
import { useTheme } from './ThemeContext';

export default function ChatPage() {
  const { teacherId } = useParams();
  const teacher = teachers.find(t => t.id === teacherId);
  const [messages, setMessages] = useState<ChatMessage[]>(mockChatHistory[teacherId || ''] || []);
  const [newMessage, setNewMessage] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();
  const { theme, toggleTheme } = useTheme();

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  if (!teacher) {
    return <div>Teacher not found</div>;
  }

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (newMessage.trim()) {
      const message: ChatMessage = {
        id: `m${Date.now()}`,
        senderId: 'user',
        text: newMessage,
        timestamp: new Date().toISOString()
      };
      setMessages([...messages, message]);
      setNewMessage('');

      // Simulate teacher response
      setTimeout(() => {
        const response: ChatMessage = {
          id: `m${Date.now()}`,
          senderId: teacherId || '',
          text: 'Thanks for your message! I\'ll get back to you soon.',
          timestamp: new Date().toISOString()
        };
        setMessages(prev => [...prev, response]);
      }, 1000);
    }
  };

  const handleComplete = () => {
    navigate(`/complete/${teacherId}`);
  };

  return (
    <div className="h-screen flex flex-col bg-gradient-to-br from-blue-50 via-purple-50 to-teal-50 dark:from-gray-900 dark:via-purple-900/20 dark:to-teal-900/20">
      {/* Header */}
      <div className="backdrop-blur-xl bg-white/70 dark:bg-gray-900/70 border-b border-gray-200/50 dark:border-gray-700/50 px-4 py-4">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link
              to={`/teacher/${teacherId}`}
              className="p-2 rounded-xl bg-gray-100 dark:bg-gray-800 hover:scale-110 transition-transform"
            >
              <ArrowLeft className="w-5 h-5 text-gray-700 dark:text-gray-200" />
            </Link>
            <img
              src={teacher.profilePhoto}
              alt={teacher.name}
              className="w-12 h-12 rounded-full object-cover"
            />
            <div>
              <h2 className="text-lg text-gray-800 dark:text-gray-100">{teacher.name}</h2>
              <p className="text-sm text-gray-500 dark:text-gray-400">{teacher.profession}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={toggleTheme}
              className="p-2 rounded-xl bg-gray-100 dark:bg-gray-800 hover:scale-110 transition-transform"
            >
              {theme === 'light' ? (
                <Moon className="w-5 h-5 text-gray-700 dark:text-gray-200" />
              ) : (
                <Sun className="w-5 h-5 text-gray-200" />
              )}
            </button>
            <button
              onClick={handleComplete}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-purple-600 to-teal-600 text-white hover:from-purple-700 hover:to-teal-700 transition-all flex items-center gap-2"
            >
              <CheckCircle2 className="w-4 h-4" />
              Complete
            </button>
          </div>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-4 py-6">
        <div className="max-w-4xl mx-auto space-y-4">
          {messages.map((message, index) => {
            const isUser = message.senderId === 'user';
            return (
              <motion.div
                key={message.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                className={`flex ${isUser ? 'justify-end' : 'justify-start'}`}
              >
                <div className={`max-w-md ${isUser ? 'order-2' : 'order-1'}`}>
                  <div
                    className={`rounded-3xl px-5 py-3 ${
                      isUser
                        ? 'bg-gradient-to-r from-purple-600 to-teal-600 text-white rounded-br-none'
                        : 'bg-white/40 dark:bg-gray-800/40 backdrop-blur-xl border border-white/20 dark:border-gray-700/20 text-gray-800 dark:text-gray-100 rounded-bl-none'
                    }`}
                  >
                    <p>{message.text}</p>
                    {message.attachments && message.attachments.length > 0 && (
                      <div className="mt-3 space-y-2">
                        {message.attachments.map((attachment, i) => (
                          <div
                            key={i}
                            className={`flex items-center gap-2 p-3 rounded-2xl ${
                              isUser
                                ? 'bg-white/20'
                                : 'bg-purple-100 dark:bg-purple-900/30'
                            }`}
                          >
                            {attachment.type === 'pdf' ? (
                              <FileText className="w-5 h-5" />
                            ) : (
                              <Video className="w-5 h-5" />
                            )}
                            <span className="text-sm">{attachment.name}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                  <p className={`text-xs text-gray-500 dark:text-gray-400 mt-1 ${isUser ? 'text-right' : 'text-left'}`}>
                    {new Date(message.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </p>
                </div>
                {!isUser && (
                  <img
                    src={teacher.profilePhoto}
                    alt={teacher.name}
                    className="w-8 h-8 rounded-full object-cover order-0 mr-2 mt-1"
                  />
                )}
              </motion.div>
            );
          })}
          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Input */}
      <div className="backdrop-blur-xl bg-white/70 dark:bg-gray-900/70 border-t border-gray-200/50 dark:border-gray-700/50 px-4 py-4">
        <div className="max-w-4xl mx-auto">
          <form onSubmit={handleSend} className="flex items-center gap-3">
            <button
              type="button"
              className="p-3 rounded-xl bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700 transition-all"
            >
              <Paperclip className="w-5 h-5 text-gray-600 dark:text-gray-300" />
            </button>
            <input
              type="text"
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              placeholder="Type your message..."
              className="flex-1 px-5 py-3 rounded-2xl bg-white/50 dark:bg-gray-800/50 border border-gray-200/50 dark:border-gray-700/50 focus:border-purple-500 dark:focus:border-purple-400 focus:ring-2 focus:ring-purple-500/20 outline-none transition-all text-gray-800 dark:text-gray-100 placeholder-gray-500 dark:placeholder-gray-400"
            />
            <motion.button
              type="submit"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="p-3 rounded-xl bg-gradient-to-r from-purple-600 to-teal-600 hover:from-purple-700 hover:to-teal-700 transition-all"
            >
              <Send className="w-5 h-5 text-white" />
            </motion.button>
          </form>
        </div>
      </div>
    </div>
  );
}
