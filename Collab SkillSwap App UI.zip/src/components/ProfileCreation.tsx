import { useState } from 'react';
import { motion } from 'motion/react';
import { Upload, CheckCircle2, Moon, Sun } from 'lucide-react';
import { useTheme } from './ThemeContext';

interface ProfileCreationProps {
  onComplete: () => void;
}

export default function ProfileCreation({ onComplete }: ProfileCreationProps) {
  const [step, setStep] = useState(1);
  const [profileData, setProfileData] = useState({
    teachSkills: '',
    learnSkills: '',
    profession: '',
    experience: '',
    education: '',
    profilePhoto: ''
  });
  const { theme, toggleTheme } = useTheme();

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setProfileData({ ...profileData, profilePhoto: reader.result as string });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (step < 3) {
      setStep(step + 1);
    } else {
      localStorage.setItem('collabProfile', JSON.stringify(profileData));
      onComplete();
    }
  };

  const progress = (step / 3) * 100;

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Gradient Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-blue-50 via-purple-50 to-teal-50 dark:from-gray-900 dark:via-purple-900/20 dark:to-teal-900/20" />
      
      {/* Animated Blobs */}
      <div className="absolute top-0 -left-20 w-96 h-96 bg-purple-300 dark:bg-purple-500/30 rounded-full mix-blend-multiply dark:mix-blend-soft-light filter blur-3xl opacity-70 animate-blob" />
      <div className="absolute top-0 -right-20 w-96 h-96 bg-teal-300 dark:bg-teal-500/30 rounded-full mix-blend-multiply dark:mix-blend-soft-light filter blur-3xl opacity-70 animate-blob animation-delay-2000" />
      
      {/* Theme Toggle */}
      <button
        onClick={toggleTheme}
        className="absolute top-6 right-6 z-10 p-3 rounded-2xl bg-white/30 dark:bg-gray-800/30 backdrop-blur-lg border border-white/20 dark:border-gray-700/20 shadow-lg hover:scale-110 transition-transform"
      >
        {theme === 'light' ? (
          <Moon className="w-5 h-5 text-gray-700 dark:text-gray-200" />
        ) : (
          <Sun className="w-5 h-5 text-gray-200" />
        )}
      </button>

      {/* Content */}
      <div className="relative z-10 min-h-screen flex items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full max-w-2xl"
        >
          {/* Progress Bar */}
          <div className="mb-8">
            <div className="flex justify-between mb-2">
              <span className="text-sm text-gray-600 dark:text-gray-300">Step {step} of 3</span>
              <span className="text-sm text-gray-600 dark:text-gray-300">{Math.round(progress)}%</span>
            </div>
            <div className="h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
              <motion.div
                className="h-full bg-gradient-to-r from-purple-600 to-teal-600"
                initial={{ width: 0 }}
                animate={{ width: `${progress}%` }}
                transition={{ duration: 0.5 }}
              />
            </div>
          </div>

          {/* Card */}
          <div className="rounded-3xl bg-white/40 dark:bg-gray-800/40 backdrop-blur-2xl border border-white/20 dark:border-gray-700/20 shadow-2xl p-8">
            <h2 className="text-3xl mb-2 text-gray-800 dark:text-gray-100">
              {step === 1 && 'Skills & Interests'}
              {step === 2 && 'Professional Background'}
              {step === 3 && 'Complete Your Profile'}
            </h2>
            <p className="text-gray-600 dark:text-gray-300 mb-8">
              {step === 1 && 'Tell us what you can teach and what you want to learn'}
              {step === 2 && 'Share your professional experience'}
              {step === 3 && 'Add your photo and finish setup'}
            </p>

            <form onSubmit={handleSubmit} className="space-y-6">
              {step === 1 && (
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="space-y-6"
                >
                  <div>
                    <label className="block mb-2 text-gray-700 dark:text-gray-200">
                      Skills You Can Teach
                    </label>
                    <textarea
                      value={profileData.teachSkills}
                      onChange={(e) => setProfileData({ ...profileData, teachSkills: e.target.value })}
                      required
                      rows={4}
                      placeholder="e.g., Web Development, Graphic Design, Photography..."
                      className="w-full px-5 py-4 rounded-2xl bg-white/50 dark:bg-gray-700/50 border border-gray-200/50 dark:border-gray-600/50 focus:border-purple-500 dark:focus:border-purple-400 focus:ring-2 focus:ring-purple-500/20 outline-none transition-all text-gray-800 dark:text-gray-100 placeholder-gray-500 dark:placeholder-gray-400 resize-none"
                    />
                  </div>
                  <div>
                    <label className="block mb-2 text-gray-700 dark:text-gray-200">
                      Skills You Want to Learn
                    </label>
                    <textarea
                      value={profileData.learnSkills}
                      onChange={(e) => setProfileData({ ...profileData, learnSkills: e.target.value })}
                      required
                      rows={4}
                      placeholder="e.g., Machine Learning, UI/UX Design, Video Editing..."
                      className="w-full px-5 py-4 rounded-2xl bg-white/50 dark:bg-gray-700/50 border border-gray-200/50 dark:border-gray-600/50 focus:border-purple-500 dark:focus:border-purple-400 focus:ring-2 focus:ring-purple-500/20 outline-none transition-all text-gray-800 dark:text-gray-100 placeholder-gray-500 dark:placeholder-gray-400 resize-none"
                    />
                  </div>
                </motion.div>
              )}

              {step === 2 && (
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="space-y-6"
                >
                  <div>
                    <label className="block mb-2 text-gray-700 dark:text-gray-200">
                      Current Profession
                    </label>
                    <input
                      type="text"
                      value={profileData.profession}
                      onChange={(e) => setProfileData({ ...profileData, profession: e.target.value })}
                      required
                      placeholder="e.g., Software Engineer, Freelance Designer..."
                      className="w-full px-5 py-4 rounded-2xl bg-white/50 dark:bg-gray-700/50 border border-gray-200/50 dark:border-gray-600/50 focus:border-purple-500 dark:focus:border-purple-400 focus:ring-2 focus:ring-purple-500/20 outline-none transition-all text-gray-800 dark:text-gray-100 placeholder-gray-500 dark:placeholder-gray-400"
                    />
                  </div>
                  <div>
                    <label className="block mb-2 text-gray-700 dark:text-gray-200">
                      Years of Experience
                    </label>
                    <input
                      type="text"
                      value={profileData.experience}
                      onChange={(e) => setProfileData({ ...profileData, experience: e.target.value })}
                      required
                      placeholder="e.g., 5 years"
                      className="w-full px-5 py-4 rounded-2xl bg-white/50 dark:bg-gray-700/50 border border-gray-200/50 dark:border-gray-600/50 focus:border-purple-500 dark:focus:border-purple-400 focus:ring-2 focus:ring-purple-500/20 outline-none transition-all text-gray-800 dark:text-gray-100 placeholder-gray-500 dark:placeholder-gray-400"
                    />
                  </div>
                  <div>
                    <label className="block mb-2 text-gray-700 dark:text-gray-200">
                      Education Background
                    </label>
                    <textarea
                      value={profileData.education}
                      onChange={(e) => setProfileData({ ...profileData, education: e.target.value })}
                      required
                      rows={3}
                      placeholder="e.g., Bachelor's in Computer Science, Self-taught..."
                      className="w-full px-5 py-4 rounded-2xl bg-white/50 dark:bg-gray-700/50 border border-gray-200/50 dark:border-gray-600/50 focus:border-purple-500 dark:focus:border-purple-400 focus:ring-2 focus:ring-purple-500/20 outline-none transition-all text-gray-800 dark:text-gray-100 placeholder-gray-500 dark:placeholder-gray-400 resize-none"
                    />
                  </div>
                </motion.div>
              )}

              {step === 3 && (
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="space-y-6"
                >
                  <div className="flex flex-col items-center">
                    <label className="block mb-4 text-gray-700 dark:text-gray-200">
                      Profile Photo
                    </label>
                    <div className="relative">
                      {profileData.profilePhoto ? (
                        <div className="relative">
                          <img
                            src={profileData.profilePhoto}
                            alt="Profile"
                            className="w-32 h-32 rounded-full object-cover border-4 border-white dark:border-gray-700 shadow-lg"
                          />
                          <div className="absolute -bottom-2 -right-2 p-2 rounded-full bg-green-500 shadow-lg">
                            <CheckCircle2 className="w-5 h-5 text-white" />
                          </div>
                        </div>
                      ) : (
                        <label className="flex flex-col items-center justify-center w-32 h-32 rounded-full border-2 border-dashed border-gray-300 dark:border-gray-600 hover:border-purple-500 dark:hover:border-purple-400 cursor-pointer transition-all bg-white/30 dark:bg-gray-700/30">
                          <Upload className="w-8 h-8 text-gray-400 dark:text-gray-500 mb-2" />
                          <span className="text-xs text-gray-500 dark:text-gray-400">Upload</span>
                          <input
                            type="file"
                            accept="image/*"
                            onChange={handlePhotoUpload}
                            className="hidden"
                          />
                        </label>
                      )}
                    </div>
                    {!profileData.profilePhoto && (
                      <p className="text-sm text-gray-500 dark:text-gray-400 mt-4">
                        Click to upload your profile photo
                      </p>
                    )}
                  </div>
                </motion.div>
              )}

              <div className="flex gap-4 pt-4">
                {step > 1 && (
                  <motion.button
                    type="button"
                    onClick={() => setStep(step - 1)}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className="flex-1 py-4 rounded-2xl bg-white/50 dark:bg-gray-700/50 border border-gray-200 dark:border-gray-600 text-gray-700 dark:text-gray-200 hover:bg-white/70 dark:hover:bg-gray-700/70 transition-all"
                  >
                    Back
                  </motion.button>
                )}
                <motion.button
                  type="submit"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="flex-1 py-4 rounded-2xl bg-gradient-to-r from-purple-600 to-teal-600 hover:from-purple-700 hover:to-teal-700 text-white shadow-lg hover:shadow-xl transition-all"
                >
                  {step === 3 ? 'Complete Profile' : 'Next'}
                </motion.button>
              </div>
            </form>
          </div>
        </motion.div>
      </div>

      <style>{`
        @keyframes blob {
          0% { transform: translate(0px, 0px) scale(1); }
          33% { transform: translate(30px, -50px) scale(1.1); }
          66% { transform: translate(-20px, 20px) scale(0.9); }
          100% { transform: translate(0px, 0px) scale(1); }
        }
        .animate-blob {
          animation: blob 7s infinite;
        }
        .animation-delay-2000 {
          animation-delay: 2s;
        }
      `}</style>
    </div>
  );
}
