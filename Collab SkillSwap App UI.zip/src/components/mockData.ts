export interface Teacher {
  id: string;
  name: string;
  profilePhoto: string;
  skills: string[];
  experience: string;
  rating: number;
  reviews: number;
  profession: string;
  education: string;
  teachingMethod: string[];
  bio: string;
  location: string;
  price?: string;
}

export interface Review {
  id: string;
  userId: string;
  userName: string;
  userPhoto: string;
  rating: number;
  comment: string;
  date: string;
}

export const teachers: Teacher[] = [
  {
    id: '1',
    name: 'Sarah Johnson',
    profilePhoto: 'https://images.unsplash.com/photo-1544972917-3529b113a469?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjB0ZWFjaGVyJTIwcG9ydHJhaXR8ZW58MXx8fHwxNzY1MzU1ODE3fDA&ixlib=rb-4.1.0&q=80&w=1080',
    skills: ['Web Development', 'React', 'TypeScript'],
    experience: '8 years',
    rating: 4.9,
    reviews: 127,
    profession: 'Senior Frontend Developer',
    education: 'BSc Computer Science, Stanford University',
    teachingMethod: ['Video Chat', 'Micro-lessons', 'Recorded Videos'],
    bio: 'Passionate about teaching modern web development. I love helping others discover the joy of coding and building beautiful, functional websites.',
    location: 'San Francisco, CA',
    price: 'Free (Skill Exchange)'
  },
  {
    id: '2',
    name: 'Marcus Chen',
    profilePhoto: 'https://images.unsplash.com/photo-1576936422505-18d321d54d40?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZXZlbG9wZXIlMjBjb2Rpbmd8ZW58MXx8fHwxNzY1MzczNjM4fDA&ixlib=rb-4.1.0&q=80&w=1080',
    skills: ['Machine Learning', 'Python', 'Data Science'],
    experience: '6 years',
    rating: 4.8,
    reviews: 93,
    profession: 'Data Scientist',
    education: 'MSc Artificial Intelligence, MIT',
    teachingMethod: ['Video Chat', 'PDFs', 'Recorded Videos'],
    bio: 'Data scientist with expertise in machine learning and AI. I enjoy making complex topics accessible and practical for learners at all levels.',
    location: 'New York, NY',
    price: 'Free (Skill Exchange)'
  },
  {
    id: '3',
    name: 'Emily Rodriguez',
    profilePhoto: 'https://images.unsplash.com/photo-1613909207039-6b173b755cc1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZXNpZ25lciUyMHdvcmtpbmd8ZW58MXx8fHwxNzY1NDI3OTQ0fDA&ixlib=rb-4.1.0&q=80&w=1080',
    skills: ['UI/UX Design', 'Figma', 'User Research'],
    experience: '7 years',
    rating: 5.0,
    reviews: 156,
    profession: 'Lead Product Designer',
    education: 'BA Design, Parsons School of Design',
    teachingMethod: ['Video Chat', 'Micro-lessons', 'PDFs'],
    bio: 'Award-winning designer passionate about creating intuitive user experiences. I teach design thinking and practical tools to bring your ideas to life.',
    location: 'Austin, TX',
    price: 'Free (Skill Exchange)'
  },
  {
    id: '4',
    name: 'Alex Thompson',
    profilePhoto: 'https://images.unsplash.com/photo-1613574450323-9df30ffe3566?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhcnRpc3QlMjBjcmVhdGl2ZXxlbnwxfHx8fDE3NjU0MDM0ODR8MA&ixlib=rb-4.1.0&q=80&w=1080',
    skills: ['Digital Illustration', 'Adobe Creative Suite', 'Character Design'],
    experience: '10 years',
    rating: 4.9,
    reviews: 201,
    profession: 'Freelance Illustrator',
    education: 'BFA Illustration, Rhode Island School of Design',
    teachingMethod: ['Recorded Videos', 'PDFs', 'Micro-lessons'],
    bio: 'Professional illustrator working with clients worldwide. I love sharing techniques and helping artists develop their unique style.',
    location: 'Portland, OR',
    price: 'Free (Skill Exchange)'
  },
  {
    id: '5',
    name: 'David Kim',
    profilePhoto: 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxidXNpbmVzcyUyMHByb2Zlc3Npb25hbHxlbnwxfHx8fDE3NjUzNTIyMjN8MA&ixlib=rb-4.1.0&q=80&w=1080',
    skills: ['Business Strategy', 'Marketing', 'Entrepreneurship'],
    experience: '12 years',
    rating: 4.7,
    reviews: 88,
    profession: 'Business Consultant',
    education: 'MBA, Harvard Business School',
    teachingMethod: ['Video Chat', 'PDFs'],
    bio: 'Former startup founder turned consultant. I help aspiring entrepreneurs turn their ideas into successful businesses.',
    location: 'Seattle, WA',
    price: 'Free (Skill Exchange)'
  },
  {
    id: '6',
    name: 'Luna Martinez',
    profilePhoto: 'https://images.unsplash.com/photo-1578410170381-5fe97ef7d370?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtdXNpY2lhbiUyMHRlYWNoZXJ8ZW58MXx8fHwxNzY1NDI3OTQ0fDA&ixlib=rb-4.1.0&q=80&w=1080',
    skills: ['Guitar', 'Music Theory', 'Songwriting'],
    experience: '9 years',
    rating: 4.9,
    reviews: 142,
    profession: 'Music Teacher & Performer',
    education: 'Bachelor of Music, Berklee College of Music',
    teachingMethod: ['Video Chat', 'Recorded Videos', 'Micro-lessons'],
    bio: 'Professional musician with a passion for teaching. I make learning music fun and accessible, whether you\'re a beginner or advancing your skills.',
    location: 'Nashville, TN',
    price: 'Free (Skill Exchange)'
  }
];

export const teacherReviews: { [key: string]: Review[] } = {
  '1': [
    {
      id: 'r1',
      userId: 'u1',
      userName: 'Mike Peterson',
      userPhoto: 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?w=100',
      rating: 5,
      comment: 'Sarah is an amazing teacher! Her explanations are clear and she\'s very patient. I went from zero to building my first React app in just 3 weeks.',
      date: '2024-11-15'
    },
    {
      id: 'r2',
      userId: 'u2',
      userName: 'Jennifer Lee',
      userPhoto: 'https://images.unsplash.com/photo-1544972917-3529b113a469?w=100',
      rating: 5,
      comment: 'Excellent teaching style! Sarah breaks down complex concepts into easy-to-understand pieces. Highly recommend!',
      date: '2024-10-28'
    },
    {
      id: 'r3',
      userId: 'u3',
      userName: 'Carlos Rivera',
      userPhoto: 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?w=100',
      rating: 4,
      comment: 'Great experience learning TypeScript with Sarah. She provided excellent resources and was always available for questions.',
      date: '2024-10-12'
    }
  ],
  '2': [
    {
      id: 'r4',
      userId: 'u4',
      userName: 'Amanda White',
      userPhoto: 'https://images.unsplash.com/photo-1544972917-3529b113a469?w=100',
      rating: 5,
      comment: 'Marcus made machine learning so much easier to understand. His real-world examples were incredibly helpful!',
      date: '2024-11-20'
    }
  ],
  '3': [
    {
      id: 'r5',
      userId: 'u5',
      userName: 'Tom Anderson',
      userPhoto: 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?w=100',
      rating: 5,
      comment: 'Emily is simply the best! Her design critiques helped me improve my portfolio dramatically.',
      date: '2024-11-18'
    }
  ]
};

export interface ChatMessage {
  id: string;
  senderId: string;
  text: string;
  timestamp: string;
  attachments?: { type: string; name: string; url: string }[];
}

export const mockChatHistory: { [key: string]: ChatMessage[] } = {
  '1': [
    {
      id: 'm1',
      senderId: '1',
      text: 'Hi! Thanks for reaching out. I\'d love to help you learn React!',
      timestamp: '2024-12-10T10:00:00Z'
    },
    {
      id: 'm2',
      senderId: 'user',
      text: 'That\'s great! I\'m excited to get started. What\'s the best way to begin?',
      timestamp: '2024-12-10T10:05:00Z'
    },
    {
      id: 'm3',
      senderId: '1',
      text: 'Let\'s start with the basics. I\'ll send you a beginner\'s guide PDF.',
      timestamp: '2024-12-10T10:07:00Z',
      attachments: [{ type: 'pdf', name: 'React-Basics-Guide.pdf', url: '#' }]
    }
  ]
};
