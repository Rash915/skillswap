import { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import LoginSignup from './components/LoginSignup';
import ProfileCreation from './components/ProfileCreation';
import Homepage from './components/Homepage';
import TeacherDetail from './components/TeacherDetail';
import ChatPage from './components/ChatPage';
import CompletionFeedback from './components/CompletionFeedback';
import { ThemeProvider } from './components/ThemeContext';

export default function App() {
  const [user, setUser] = useState<any>(null);
  const [profileComplete, setProfileComplete] = useState(false);

  useEffect(() => {
    const storedUser = localStorage.getItem('collabUser');
    const storedProfile = localStorage.getItem('collabProfile');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
      if (storedProfile) {
        setProfileComplete(true);
      }
    }
  }, []);

  return (
    <ThemeProvider>
      <BrowserRouter>
        <Routes>
          <Route 
            path="/" 
            element={
              !user ? (
                <LoginSignup onLogin={setUser} />
              ) : !profileComplete ? (
                <Navigate to="/profile-setup" replace />
              ) : (
                <Navigate to="/home" replace />
              )
            } 
          />
          <Route 
            path="/profile-setup" 
            element={
              user ? (
                <ProfileCreation onComplete={() => setProfileComplete(true)} />
              ) : (
                <Navigate to="/" replace />
              )
            } 
          />
          <Route 
            path="/home" 
            element={
              user && profileComplete ? (
                <Homepage user={user} />
              ) : (
                <Navigate to="/" replace />
              )
            } 
          />
          <Route 
            path="/teacher/:id" 
            element={
              user && profileComplete ? (
                <TeacherDetail />
              ) : (
                <Navigate to="/" replace />
              )
            } 
          />
          <Route 
            path="/chat/:teacherId" 
            element={
              user && profileComplete ? (
                <ChatPage />
              ) : (
                <Navigate to="/" replace />
              )
            } 
          />
          <Route 
            path="/complete/:teacherId" 
            element={
              user && profileComplete ? (
                <CompletionFeedback />
              ) : (
                <Navigate to="/" replace />
              )
            } 
          />
        </Routes>
      </BrowserRouter>
    </ThemeProvider>
  );
}
